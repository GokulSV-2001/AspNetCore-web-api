using NZwalks.Api.Models.Domain;

namespace NZwalks.Api.Models.DTO
{
    public class WalkDto
    {
        public Guid Id{get;set;}
        public string Name { get; set; }
       public string Description { get; set; }
        public double LengthInKm { get; set; }
        public string? WalkImageUrl { get; set; }
    //     public Guid RegionId { get; set; }
    //    public Guid DifficultyId { get; set; }

        //navation properties
        public DifficultyDto difficulty {get;set;}
        public RegionDto region{get;set;}
    }
}
